package PDP_Questions;
import java.util.Scanner;
import java.util.Random;
public class Main {


    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.print("100-999 orasidan son kirit : ");
        int number = scan.nextInt();
        if( number < 1000 & number > 99) {
            int ones = number % 10;
            int tens = number / 10 % 10;
            int hundreds = number / 100 % 10;
            switch (hundreds) {
                case 1 -> System.out.print(" bir yuz ");
                case 2 -> System.out.print(" ikki yuz ");
                case 3 -> System.out.print(" uch yuz ");
                case 4 -> System.out.print(" to'rt yuz ");
                case 5 -> System.out.print(" besh yuz ");
                case 6 -> System.out.print(" olti yuz ");
                case 7 -> System.out.print(" yetti yuz ");
                case 8 -> System.out.print(" sakkiz yuz ");
                case 9 -> System.out.print(" to'qqiz yuz ");
            }
            switch (tens) {
                case 0 -> System.out.print(" ");
                case 1 -> System.out.print(" o'n ");
                case 2 -> System.out.print(" yigirma ");
                case 3 -> System.out.print(" o'ttiz ");
                case 5 -> System.out.print(" ellik ");
                case 6 -> System.out.print(" oltmish ");
                case 7 -> System.out.print(" yetmish ");
                case 8 -> System.out.print(" sakson ");
                case 9 -> System.out.print(" to'qson ");
                case 4 -> System.out.print(" qirq ");
            }
            switch (ones) {
                case 0 -> System.out.print(" ");
                case 1 -> System.out.print(" bir ");
                case 2 -> System.out.print(" ikki ");
                case 3 -> System.out.print(" uch ");
                case 4 -> System.out.print(" to'rt ");
                case 5 -> System.out.print(" besh ");
                case 6 -> System.out.print(" olti ");
                case 7 -> System.out.print(" yetti ");
                case 8 -> System.out.print(" sakkiz ");
                case 9 -> System.out.print(" to'qqiz ");
            }
        }
        else
            System.out.println("Noto'g'ri raqam kiritding!!!");

    }




}